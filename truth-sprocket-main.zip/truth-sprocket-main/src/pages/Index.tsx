import AIDetector from "@/components/AIDetector";

const Index = () => {
  return <AIDetector />;
};

export default Index;
